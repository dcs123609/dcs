create
    definer = root@localhost procedure pro_del(IN i int)
begin
 delete from staff where id=i;
end;

