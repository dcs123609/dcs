create
    definer = root@localhost procedure pro_count(OUT n int)
begin
select count(*) from staff into n;
end;

