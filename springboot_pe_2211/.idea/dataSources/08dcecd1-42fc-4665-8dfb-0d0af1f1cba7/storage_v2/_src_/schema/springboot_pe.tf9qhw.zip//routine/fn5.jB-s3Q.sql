create
    definer = root@localhost function fn5(id int) returns varchar(20)
begin
 DECLARE name varchar(20);
 select sname from student where sno=id into name;
 return name;
end;

