create
    definer = root@localhost function fn2(id int) returns varchar(20)
begin
declare name varchar(20);
select sname from student where sno=id into name;
return name;
end;

