create
    definer = root@localhost function fn4(id int) returns varchar(20)
begin
 DECLARE sname varchar(20);
 select name from student where sno=id into sname;
 return sname;
end;

