create
    definer = root@localhost procedure bank_updates(IN card_number1 varchar(50), IN money_num int, IN pass_word int,
                                                    IN card_number2 varchar(50))
BEGIN
    #定义变量
    DECLARE money DECIMAL(10,2);
    DECLARE card_num_1 VARCHAR(50);
    DECLARE card_num_2 VARCHAR(50);
    DECLARE pass INT;
    #查出李四银行卡卡号
    SELECT card_num
    INTO card_num_1
    FROM card_info
             JOIN user_info ON card_info.user_id = user_info.user_id
    WHERE NAME = '李四';
    #查出张三银行卡卡号
     SELECT card_num
    INTO card_num_2
    FROM card_info
             JOIN user_info ON card_info.user_id = user_info.user_id
    WHERE NAME = '张三';
    #查询出将要进行转账操作的卡号信息密码
    SELECT PASSWORD INTO pass FROM card_info WHERE card_num = card_number1;
    #查出将要进行转账操作的卡号余额
    SELECT balance INTO money FROM card_info WHERE card_num = card_number1;
    #开始事务
    START TRANSACTION ;
    #首先进行判断输入要转账的银行卡卡号以及要接收转账的银行卡卡号是否正确
    IF card_num_1 != card_number1 or card_num_2 != card_number2 THEN
       select '卡号输入错误';
    elseif card_num_1 = card_number1 and card_num_2 = card_number2 then
        #再次判断要转账的银行卡卡后密码是是否正确，以及余额是否足以转账
       IF pass = pass_word AND money >= money_num THEN
        #进行转账操作李四给张三
       UPDATE card_info SET balance = balance - money_num WHERE card_num = card_number1;
       #将交易信息存入交易信息表
       INSERT INTO trade_info(card_id,service_id,card_num,trade_date,trade_num,trade_type,ps) VALUES
      (10002,1006, card_number1, CURRENT_DATE, money_num, 2, CONCAT('自动转账取出',money_num,'元'));
       #接收李四转过来的钱
       UPDATE card_info SET balance = balance + money_num WHERE card_num = card_number2;
       #同时更新交易信息表
      INSERT INTO trade_info(card_id,service_id,card_num,trade_date,trade_num,trade_type,ps) VALUES
      (10001,1006,card_number2, CURRENT_DATE, money_num, 1,CONCAT('自动转账存入',money_num,'元'));
       SELECT '操作成功';
         #如果密码正确但是余额不足，则提示余额不足,转账失败，同时回滚事务
         ELSEIF pass = pass_word AND money < money_num  THEN
           SELECT '余额不足,转账失败';
           #同时回滚事务
           ROLLBACK ;
           #密码错误，转账失败
         ELSE
           SELECT '密码错误,无法转账';
        #结束内层if判断
       END IF ;
       #结束外层if判断
    END IF ;
END;

